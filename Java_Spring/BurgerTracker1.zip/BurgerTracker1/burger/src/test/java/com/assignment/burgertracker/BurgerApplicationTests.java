package com.assignment.burgertracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BurgerApplicationTests {

	@Test
	void contextLoads() {
	}

}
